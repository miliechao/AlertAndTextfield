//
//  PLAudioStreamingViewController.h
//  PLCameraStreamingKit
//
//  Created by 0dayZh on 15/9/28.
//  Copyright © 2015年 0dayZh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PLAudioStreamingViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *actionButton;

@end
