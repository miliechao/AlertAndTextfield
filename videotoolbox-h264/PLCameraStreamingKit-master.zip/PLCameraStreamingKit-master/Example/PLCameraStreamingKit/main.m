//
//  main.m
//  PLCameraStreamingKit
//
//  Created by 0dayZh on 01/10/2015.
//  Copyright (c) 2014 0dayZh. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "PLAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([PLAppDelegate class]));
    }
}
