# PLCameraStreamingKit 1.3.0 to 1.3.1 API Differences

## General Headers

None