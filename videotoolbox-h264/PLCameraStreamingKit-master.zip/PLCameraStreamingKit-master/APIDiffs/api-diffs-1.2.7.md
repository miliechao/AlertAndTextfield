# PLCameraStreamingKit 1.2.6 to 1.2.7 API Differences

## General Headers

```PLCameraStreamingSession.h```

- *Added* `- (void)destroy;`