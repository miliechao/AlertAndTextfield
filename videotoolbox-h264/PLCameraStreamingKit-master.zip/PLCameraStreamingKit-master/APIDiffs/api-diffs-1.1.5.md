# PLCameraStreamingKit 1.1.4 to 1.1.5 API Differences

## General Headers

None