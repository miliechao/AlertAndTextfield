# PLCameraStreamingKit 1.2.7 to 1.2.8 API Differences

## General Headers
