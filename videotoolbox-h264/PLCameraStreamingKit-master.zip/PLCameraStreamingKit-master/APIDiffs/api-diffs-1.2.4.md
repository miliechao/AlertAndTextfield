# PLCameraStreamingKit 1.2.3 to 1.2.4 API Differences

## General Headers

None