# PLCameraStreamingKit 1.3.2 to 1.4.0 API Differences

## General Headers

```PLTypeDefines.h```

- *Added* type `PLStreamingBackgroundMode`

```PLAudioStreamingSession.h```

- *Added* class `PLAudioStreamingSession`