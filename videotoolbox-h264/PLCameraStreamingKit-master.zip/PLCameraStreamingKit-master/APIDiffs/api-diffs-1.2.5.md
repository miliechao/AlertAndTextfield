# PLCameraStreamingKit 1.2.4 to 1.2.5 API Differences

## General Headers

```PLTypeDefines.h```

- *Modified* Quality
- *Added* `kPLStreamingQualityLow3`