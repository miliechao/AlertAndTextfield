# PLCameraStreamingKit 1.1.7 to 1.1.8 API Differences

## General Headers

```
PLCameraStreamingSession.h
```

- *Added* `- (void)startCaptureSession;`
- *Added* `- (void)stopCaptureSession;`