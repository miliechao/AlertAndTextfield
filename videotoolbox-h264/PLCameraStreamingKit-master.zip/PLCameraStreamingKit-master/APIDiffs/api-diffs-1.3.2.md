# PLCameraStreamingKit 1.3.1 to 1.3.2 API Differences

## General Headers

None