# PLCameraStreamingKit 1.2.0 to 1.2.1 API Differences

## General Headers

None