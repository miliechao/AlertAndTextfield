# PLCameraStreamingKit 1.2.5 to 1.2.6 API Differences

## General Headers

None