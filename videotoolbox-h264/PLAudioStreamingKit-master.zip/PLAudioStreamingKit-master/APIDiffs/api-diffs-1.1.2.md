# PLAudioStreamingKit 1.1.1 to 1.1.2 API Differences

## General Headers

None