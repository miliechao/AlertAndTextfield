# PLAudioStreamingKit 1.0.0 to 1.0.0 API Differences

## General Headers

None