# PLAudioStreamingKit 1.1.2 to 1.1.3 API Differences

## General Headers

None