# PLAudioStreamingKit 1.0.1 to 1.0.2 API Differences

## General Headers

None