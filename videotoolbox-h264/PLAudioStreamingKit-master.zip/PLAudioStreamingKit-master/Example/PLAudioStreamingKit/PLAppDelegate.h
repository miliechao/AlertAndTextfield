//
//  PLAppDelegate.h
//  PLAudioStreamingKit
//
//  Created by CocoaPods on 04/28/2015.
//  Copyright (c) 2014 0dayZh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
