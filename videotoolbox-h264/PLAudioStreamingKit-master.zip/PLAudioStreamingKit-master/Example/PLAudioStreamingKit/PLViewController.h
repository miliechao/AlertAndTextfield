//
//  PLViewController.h
//  PLAudioStreamingKit
//
//  Created by 0dayZh on 04/28/2015.
//  Copyright (c) 2014 0dayZh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PLViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *actionButton;

@end
