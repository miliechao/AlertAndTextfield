# iOS-h264Hw-Toolbox
Simple iOS8 app which uses new iOS8 based hardware acceleration for H264 (Using videotoolbox)
