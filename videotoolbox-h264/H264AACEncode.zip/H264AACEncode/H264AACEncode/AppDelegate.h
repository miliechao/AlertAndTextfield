//
//  AppDelegate.h
//  H264AACEncode
//
//  Created by ZhangWen on 15/10/14.
//  Copyright © 2015年 Zhangwen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

