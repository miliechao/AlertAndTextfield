//
//  main.m
//  Encoder Demo
//
//  Created by Geraint Davies on 11/01/2013.
//  Copyright (c) 2013 Geraint Davies. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "EncoderDemoAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([EncoderDemoAppDelegate class]));
    }
}
