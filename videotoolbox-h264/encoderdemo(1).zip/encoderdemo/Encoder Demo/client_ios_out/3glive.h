 
#ifndef _3G_LIVE_H_
#define _3G_LIVE_H_
 
#include <time.h>
#ifdef UNIX
#include <sys/time.h>
#include <netinet/in.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif
 
#ifndef __KE_BTYPE_H__
typedef unsigned long long  uint64;
typedef long long           sint64;
typedef long long           int64;
typedef unsigned long       ulong;
typedef unsigned int        uint32;
typedef int                 sint32;
typedef int                 int32;
typedef unsigned short int  uint16;
typedef short int           sint16;
typedef short int           int16;
typedef unsigned char       uint8;
typedef char                sint8;
typedef char                int8;
#endif

typedef int AVPushFunc (void * vsess, void * vnalu);
typedef int EncParaSetFunc (void * vsess, void * vnalu);

typedef struct live_nalu {
    uint32           naluid;
    struct timeval   createtime;
    time_t           lastvisit;
 
    uint8            type;      //0-video 1-audio
    uint8            keyframe;  //1-keyframe
    uint32           timestamp; //relative to the start_timestamp
    uint32           ctoff;     //Composition Time Offset
         
         
    //1-Slice  2-DPA   3-DPB      4-DPC         5-IDR   6-SEI   7-SPS
    //8-PPS    9-AUD   10-EOSEQ   11-EOSTREAM   12-FILLER
    uint8            nalutype;
    //0-Disposable  1-Low  2-High  3-Highest
    uint8            priority;
         
         
    uint32           size;
    uint32           bytelen;
    uint8          * pbyte; 
} LiveNalu;

 
typedef struct encodepara_ {
  
    uint64             start_timestamp;
    uint8              has_video;
    uint8              has_audio;
    uint16             video_width;
    uint16             video_height;
    uint16             video_fps;
    uint16             audio_samplerate;
 
    uint8              avc_sps_len;
    uint8              avc_sps[256];
    uint8              avc_pps_len;
    uint8              avc_pps[64];
 
    //0-AAC main, 1-AAC lc, 2-AAC ssr, 3-AAC LTP
    uint8              aac_objtype;
    //0=96000Hz, 1=88200Hz, 2=64000Hz, 3=48000Hz, 4=44100Hz
    uint8              aac_samplefreqind;
    uint8              aac_channel;  //1-mono, 2-stero
 
} EncodePara;
 

typedef struct MLinkPara {

    EncodePara         encpara;
    EncParaSetFunc   * encparaset;

    AVPushFunc       * avpush;
    void             * pushpara;
} MLinkPara;


typedef struct sess_stat {
    uint16             sessid;
    struct in_addr     ip;
    int                port;

    /* FIFO stat */
    int                bgn_nalu;      //begining index of Nalu to be sent to server
    int                nalu_num;      //the Nalu Number not synchronized to server
    int                fifo_num;      //max Nulu Number contained in FIFO
    uint32             last_naluid;   //incoming NaluID to be pushed to FIFO

    /* FIFO Nalu stat */
    double             push_rate;            //KB/s, Captured Video/Audio pushing speed to FIFO
    int64              video_nalu;           //total pushed Video Nalu number
    int64              video_nalu_byte;      //total pushed Video Nalu bytes
    int64              audio_nalu;           //total pushed Aduio Nalu number
    int64              audio_nalu_byte;      //total pushed Audio Nalu bytes
    int64              lost_video_nalu;      //total lost Video Nalu number not sent to livesrv
    int64              lost_video_nalu_byte; //total lost Video Nalu bytes not sent to livesrv
    int64              lost_audio_nalu;      //total lost Aduio Nalu number not sent to livesrv
    int64              lost_audio_nalu_byte; //total lost Audio Nalu bytes not sent to livesrv

    /* Network I/O stat */
    double             send_rate;   //KB/s, total sending speed to LiveSrv via all Network Ifac
    double             recv_rate;   //KB/s, total recving speed from LiveSrv via all Network Ifac
    int64              acc_sent;    //Byte number that accumulated sent to LiveSrv
    int64              acc_recv;    //Byte number that accumulated recv from LiveSrv

    /* Nalu PDU sync stat and memory stat */
    int                wait_resp_num;  //JobUnit number sent to LiveSrv but not acknowledged
    int                wait_pack_num;  //LivePack number ongoing sending to LiveSrv but not acked
    int                send_job_num;   //JobUnit number to be sent to LiveSrv
    int                nalu_pool_num;  //LiveNalu number standing as pool
    int                fetch_pack_num; //LivePack outstanding

    /* IP Terminal stat */
    int                termnum;     //IP terminal number
    int                tcpnum;      //TCP connection number
    struct {
        struct in_addr ip;
        int            iptype;      //NicType defined in tsock.h
        int            tcpnum;      //TCP number

        double         send_rate;   //KB/s, total sending speed to LiveSrv via current IP Ifac
        double         recv_rate;   //KB/s, total recving speed from LiveSrv via current IP Ifac
        int64          acc_sent;    //Byte number that accumulated sent to LiveSrv
        int64          acc_recv;    //Byte number that accumulated recv from LiveSrv
    } ipterm[12];

} SessStat;


void * live_mgmt_init  (void * pcore, void * hconf);
int    live_mgmt_clean (void * vmgmt);

void * live_sess_open (void * vmgmt, void * venc, int fifonum, uint8 * host, int port);
int    live_sess_close(void * vsess);

int    live_sess_set_encpara (void * vsess, void * vencpara);

void   live_sess_stat (void * vsess, void * vstat);

int    live_fifo_push (void * vsess, void * vnalu);

void * encode_on_davinci(void * arg);

/**************** User Example ******************
int main() {

    sysquit = event_create();

    hconf = conf_mgmt_init("3glive.conf");

    pcore = probe_init(conf_get_int(hconf, "Probe System Generic Option", "Conn Max Idle Time"),
                       conf_get_int(hconf, "Probe System Generic Option", "Max threads"),
                       conf_get_int(hconf, "Probe System Generic Option", "Min threads"),
                       conf_get_int(hconf, "Probe System Generic Option", "Thread Life idle seconds"), 0);

    //fill the member of EncodingPara, including LiveNalu free function
    fill_encoding_para(encpara, ...);

    livemgmt = live_mgmt_inti(pcore, hconf);
    livesess = live_sess_open(livemgmt, encpara, 2000, "3glive.downsha.com", 7266);

    //set the output callback for H.264 Encoder
    set_output_callback(..., live_fifo_push, livesess);

#ifdef _DEBUG 
    StartProbe(pcore, 1); 
    while (event_wait(sysquit, 10*60*1000) != -10) continue;
    event_destroy(sysquit);
  #endif                
#else                   
    StartProbe(pcore, 0);
#endif
    return 0;
}
 *************** End of Example *****************/


#ifdef __cplusplus
}
#endif
 
#endif
 

