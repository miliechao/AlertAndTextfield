
#ifndef _PROBE_H_
#define _PROBE_H_


#ifdef WINDOWS

#include <winsock2.h>
#include <ws2tcpip.h>

#if _MSC_VER > 1000
#pragma once
#endif

#pragma pack(1)

struct tcp_keepalive {
    u_long onoff;
    u_long keepalivetime;
    u_long keepaliveinterval;
};
#pragma pack()  /* ȡ��ָ�����룬�ָ�ȱʡ���뷽ʽ */


#define SIO_RCVALL            _WSAIOW(IOC_VENDOR, 1)
#define SIO_RCVALL_MCAST      _WSAIOW(IOC_VENDOR, 2)
#define SIO_RCVALL_IGMPMCAST  _WSAIOW(IOC_VENDOR, 3)
#define SIO_KEEPALIVE_VALS    _WSAIOW(IOC_VENDOR, 4)
#define SIO_ABSORB_RTRALERT   _WSAIOW(IOC_VENDOR, 5)
#define SIO_UCAST_IF          _WSAIOW(IOC_VENDOR, 6)
#define SIO_LIMIT_BROADCASTS  _WSAIOW(IOC_VENDOR, 7)
#define SIO_INDEX_BIND        _WSAIOW(IOC_VENDOR, 8)
#define SIO_INDEX_MCASTIF     _WSAIOW(IOC_VENDOR, 9)
#define SIO_INDEX_ADD_MCAST   _WSAIOW(IOC_VENDOR, 10)
#define SIO_INDEX_DEL_MCAST   _WSAIOW(IOC_VENDOR, 11)

#define RCVALL_OFF              0
#define RCVALL_ON               1
#define RCVALL_SOCKETLEVELONLY  2

#endif

#ifdef __cplusplus
extern "C" {
#endif

#pragma pack(1)

typedef struct ip_hdr
{
    uint8  ip_verlen; 
    uint8  ip_tos; 
    uint16 ip_totallength; 
    uint16 ip_id; 
    uint16 ip_offset; 
    uint8  ip_ttl; 
    uint8  ip_protocol; 
    uint16 ip_checksum; 
    uint32 ip_srcaddr; 
    uint32 ip_destaddr; 
} IP_HDR;

typedef struct udp_hdr
{
    uint16 src_portno; 
    uint16 dst_portno; 
    uint16 udp_length; 
    uint16 udp_checksum; 
} UDP_HDR;


/* define the ICMP header 
 * Destination Unreachable Message */
typedef struct imcp_hdr {
    uint8   icmp_type;      /* type */
    uint8   icmp_code;      /* Code */
    uint16  icmp_checksum;  /* Checksum */
    uint16  icmp_id;        /* identification */
    uint16  icmp_seq;       /* sequence no */
    uint32  icmp_timestamp; /* timestamp */
} ICMP_HDR, *PICMP_HDR;

#pragma pack()  /* ȡ��ָ�����룬�ָ�ȱʡ���뷽ʽ */


#define ICMP_ECHO_REPLY      0
#define ICMP_DEST_UNREACH    3
#define ICMP_SRC_QUENCH      4
#define ICMP_REDIRECT        5
#define ICMP_ECHO            8
#define ICMP_TIME_EXCEEDED   11
#define ICMP_PARA_PROBLEM    12
#define ICMP_TIMESTAMP       13  
#define ICMP_TIMESTAMP_REPLY 14  
#define ICMP_INFO_REQUEST    15
#define ICMP_INFO_REPLY      16


#ifndef IOHandler_macro
typedef int (IOHandler)(void * vmgmt, void * pobj, int event, int fdtype);
#define IOHandler_macro 1
#endif



/* set the notify type for the device */
#define RWF_READ  0x02
#define RWF_WRITE 0x04



/* event type in the callback function.
 * including connected, acceptable, readable,
 * writable, crashed, timeout. the working threads will be driven by these events */
#define IOE_CONNECTED        1
#define IOE_CONNFAIL         2
#define IOE_ACCEPT           3
#define IOE_READ             4
#define IOE_POOLACCCON_READ  5
#define IOE_POOLCON_READ     6
#define IOE_WRITE            7
#define IOE_CRASH            8
#define IOE_TIMEOUT          9
#define IOE_INVALID_DEV      10
#define IOE_USER_DEFINED     10000



/* TCP/UDP socket FD type definition */
#define FDT_LISTEN            0x01
#define FDT_CONNECTED         0x02
#define FDT_ACCEPTED          0x04
#define FDT_UDPSRV            0x08
#define FDT_UDPCLI            0x10
#define FDT_RAWSOCK           0x20
#define FDT_TIMER             0x40
#define FDT_USERCMD           0x80
#define FDT_LINGER_CLOSE      0x100
#define FDT_STDIN             0x200
#define FDT_STDOUT            0x400
#define FDT_USOCK_LISTEN      0x801
#define FDT_USOCK_CONNECTED   0x802
#define FDT_USOCK_ACCEPTED    0x804



int ProbeUptime (void * vprobe);
int StartProbe (void * vprobe, uint8 forkone);
int StopProbe (void * vprobe);

SOCKET ProbeUDPFD (void * vprobe);
uint16 ProbeUDPPort (void * vprobe);


int    SetSystemCallback (void * vpcore, IOHandler * callback, void * callbackpara);
int    SetNotify         (void * vdev, uint8 rwflag);

//#ifdef _DEBUG
//int RemoveDevice_dbg(void * vdev, char * file, int line);
//#define RemoveDevice(vdev) RemoveDevice_dbg((vdev), __FILE__, __LINE__)
//#else
int RemoveDevice(void * vdev);
//#endif

//int    RemoveDevice      (void * vdev);
int    LingerRemoveDevice (void * vdev);
int    ReuseDevice       (void * vdev);

int GetDeviceTCPNum (void * pcore);

void * SetDevicePara     (void * vdev, void * para);
int    SetDeviceCallback (void * vpdev, IOHandler * callback, void * callbackpara);

void         * GetDevicePara       (void * vdev);
SOCKET         GetDeviceFD         (void * vpdev);
uint8          GetDeviceFDType     (void * vpdev);
struct in_addr GetDeviceRemoteIP   (void * vpdev);
uint16         GetDeviceRemotePort (void * vpdev);
struct in_addr GetDeviceLocalIP    (void * vpdev);
uint16         GetDeviceLocalPort  (void * vpdev);


int ShowDevices (void * vprobe, FRAME_PTR * devfrm);

void * WaitStdinInput (void * vpcore, void * para, IOHandler * ioh, void * iohpara);
int    StdinInputHandler (void * vpcore, void * pobj, int event, int fdtype);

void * ConnectRemote (void * vpcore, struct in_addr ip, uint16 port, void * para, 
                      int * retval, IOHandler * ioh, void * iohpara);
void * ListenRemote  (void * vpcore, uint16 port, void * para, int * retval);
void * AcceptRemote  (void * vpcore, void * vld, int * retval);
void * ListenUDP     (void * vpcore, uint16 port, void * para, int * retval);

void * ConnectRemoteFull(void * vpcore, struct in_addr ip, uint16 port,
                         char * localip, int localport, void * para,
                         int * retval, IOHandler * ioh, void * iohpara);
void * ConnectRemote3(void * vpcore, uint8 * host, uint16 port,
                      char * localip, int localport, void * para,
                      int * retval, IOHandler * ioh, void * iohpara);
void * ConnectRemote2(void * vpcore, uint8 * host, uint16 port, 
                       void * para, int * retval, IOHandler * ioh, void * iohpara);
void * ListenRemote2 (void * vpcore, uint16 port, void * para, int * retval,
                       IOHandler * cb, void * cbpara);
void * AcceptRemote2 (void * vpcore, void * vld, void * para, int * retval,
                       IOHandler * cb, void * cbpara);
void * ListenUDP3(void * vpcore, struct in_addr * localip, uint16 port, 
                  void * para, int * retval, IOHandler * cb, void * cbpara);
void * ListenUDP2    (void * vpcore, uint16 port, void * para, int * retval,
                       IOHandler * cb, void * cbpara);
void * UDPServerBind (void * vpcore, SOCKET fd, uint16 port, 
                      void * para, IOHandler * cb, void * cbpara);

void * UDPClient (void * vpcore, struct in_addr * localip, uint16 port, 
                  void * para, int * retval, IOHandler * cb, void * cbpara);

uint16 rfc_checksum    (uint16 * buffer, int size);
void * RawSockClient   (void * vpcore, void * para, int protocol, int * retval);
int    RawSockNotify   (void * vpdev, int recvall, IOHandler * cb, void * cbpara);
int    RawSockSendUDP  (void * vpdev, char * srcip, uint16 srcport, 
                        char * dstip, uint16 dstport, 
                        uint8 * pbyte, int bytelen);
int    RawSockSendICMP (void * vpdev, char * srcip, char * dstip, 
                        uint8 icmptype, uint16 icmpid, uint16 icmpseq,
                        uint8 * pbyte, int bytelen);


//#ifdef _DEBUG
//void * StartTimer_dbg(void * vpcore, int ms, int cmdid, void * para, char * file, int line);
//#define StartTimer(vpcore, ms, cmdid, para) StartTimer_dbg((vpcore), (ms), (cmdid), (para), __FILE__, __LINE__)
//#else
void * StartTimer(void * vpcore, int ms, int cmdid, void * para);
//#endif 


//#ifdef _DEBUG
//void * StartTimer2_dbg(void * vpcore, int ms, int cmdid, void * para,
//                       IOHandler * cb, void * cbpara, char * file, int line);
//#define StartTimer2(vpcore, ms, cmdid, para, cb, cbpara) StartTimer2_dbg((vpcore), (ms), (cmdid), (para),(cb), (cbpara),  __FILE__, __LINE__)
//#else
void * StartTimer2(void * vpcore, int ms, int cmdid, 
                   void * para, IOHandler * cb, void * cbpara);
//#endif


//#ifdef _DEBUG
//int StopTimer_dbg(void * vtimer, char * file, int line);
//#define StopTimer(vtimer) StopTimer_dbg((vtimer), __FILE__, __LINE__)
//#else
int StopTimer(void * vtimer);
//#endif

int    SetTimeoutCallback (void * vtimer, IOHandler * callback, void * callbackpara);
void * GetTimeoutPara     (void * vtimer);
int    GetTimeoutCmd      (void * vtimer);

int PushUserEvent (void * vpcore, int event, void * obj, void * handler, void * handlerpara);
int DrivePump (void * vpcore);
int DriveMonitor (void * vpcore);

int RegisterHook (void * vpcore, void * ignitor, void * igpara,
                   void * callback, void * cbpara);
int RemoveHook (void * vpcore, void * ignitor, void * igpara, 
                   void * callback, void * cbpara);


void * probe_init (int connidletime, int maxthread, int minthread, int threadlifetime, int maxfd);
int    probe_cleanup (void * pcore);

void  * pcore_lic_init (uint8 * nodename, uint8 banenable, void * pcore, void * encoder);
int     pcore_lic_cleanup (void * vlic);
int     pcore_lic_set_execopen (void * vlic, void * openfunc, void * execmgmt);
int     pcore_lic_set_confsave (void * vlic, void * savefunc, void * confmgmt);
uint8 * pcore_lic_nodename (void * vlic);
uint32  pcore_lic_nodeid   (void * vlic);

void    BanProbe (void * vprobe, int banned);
int     ProbeBanned (void * vprobe);


#ifdef __cplusplus
}
#endif

#endif

